import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class AddStudent extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String Roll = request.getParameter("StudentRollNumber");

        // Check if the student with the same roll number already exists
        if (isStudentExists(Roll)) {
            out.println("<h2>Student with roll number " + Roll + " already exists.</h2>");
			out.println("<html><head>");
                out.println("<title>Click to Go to Home Page</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Click the link below to go to the home page:</h2>");
                out.println("<a href=page.html>Home Page</a>");
                out.println("</body></html>");
        } else {
            // If the student doesn't exist, proceed with insertion
            String Name = request.getParameter("StudentName");
            String English = request.getParameter("EnglishNumber");
            String Scince = request.getParameter("ScinceNumber");
            String Math = request.getParameter("MathematicsNumber");
            String Hindi = request.getParameter("HindiNumber");
            String Social = request.getParameter("SocialNumber");
            int e = Integer.parseInt(English);
            int s = Integer.parseInt(Scince);
            int m = Integer.parseInt(Math);
            int h = Integer.parseInt(Hindi);
            int sc = Integer.parseInt(Social);
            int TotalNumber = e + s + m + h + sc;
            double percentage = (TotalNumber / 500.0) * 100;

            String st = "";
            if (percentage < 33) {
                st = "Fail";
            } else {
                st = "Pass";
            }
            String tn = Integer.toString(TotalNumber);

            boolean queryExecuted = false;
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection(
                        "jdbc:oracle:thin:@localhost:1521:xe", "SUMIT", "1234");

                String sq = "INSERT INTO Student(STUDENT_ROLL,STUDENT_NAME,ENGLISH,SCINCE,MATHEMATICS,HINDI,SOCIAL_SCIENCE,MARKS,STATUS) VALUES (?, ?, ?,?,?,?,?,?,?)";
                PreparedStatement pre = con.prepareStatement(sq);
                pre.setString(1, Roll);
                pre.setString(2, Name);
                pre.setString(3, English);
                pre.setString(4, Scince);
                pre.setString(5, Math);
                pre.setString(6, Hindi);
                pre.setString(7, Social);
                pre.setString(8, tn);
                pre.setString(9, st);

                int x = pre.executeUpdate();

                out.println("DATA INSERT................");
                out.println("<br>");
                out.println("<h2>" + x + " student is added</h2>");

                out.println("<html><head>");
                out.println("<title>Click to Go to Home Page</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Click the link below to go to the home page:</h2>");
                out.println("<a href=page.html>Home Page</a>");
                out.println("</body></html>");

            } catch (Exception e2) {
                System.out.println(e2);
            }
        }

        out.close();
    }

    // Check if a student with the given roll number already exists in the database
    private boolean isStudentExists(String rollNumber) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "SUMIT", "1234");

            String query = "SELECT * FROM Student WHERE STUDENT_ROLL = ?";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, rollNumber);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // If the result set has at least one row, the student exists

        } catch (Exception e) {
            e.printStackTrace();
            return false; // Return false in case of any error
        }
    }
}
