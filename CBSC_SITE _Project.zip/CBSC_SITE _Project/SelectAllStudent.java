import java.io.*;  
import java.sql.*;  
import javax.servlet.ServletException;  
import javax.servlet.http.*;  
  
public class SelectAllStudent extends HttpServlet {  

public void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
  
response.setContentType("text/html");  
PrintWriter out = response.getWriter();  
          
String Roll=request.getParameter("StudentRollNumber");  
String Name=request.getParameter("StudentName");  
       
try{  
Class.forName("oracle.jdbc.driver.OracleDriver");  
Connection con=DriverManager.getConnection(  
"jdbc:oracle:thin:@localhost:1521:xe","SUMIT","1234");  


Statement stmt=con.createStatement();
String sq="Select * From Student";
ResultSet rs=stmt.executeQuery(sq);
int count=0;

while (rs.next()) 
{
	int totalMarks=0;
    out.println("<h2>"+"Student Roll Number =" + rs.getString(1)+"</h2>");
	out.println("<h2>"+"Student Name        =" + rs.getString(2)+"</h2>");
	out.println("<h2>"+"English Marks       =" + rs.getString(3)+"</h2>");
	out.println("<h2>"+"Scince Marks        =" + rs.getString(4)+"</h2>");
	out.println("<h2>"+"Mathematic Marks    =" + rs.getString(5)+"</h2>");
	out.println("<h2>"+"Hindi Marks         =" + rs.getString(6)+"</h2>");
	out.println("<h2>"+"Social Scince Marks =" + rs.getString(7)+"</h2>");
	out.println("<h2>"+"Student Status      =" + rs.getString(9)+"</h2>");
    out.println("<br>");
	
	
	int e=rs.getInt("ENGLISH");
	int s=rs.getInt("SCINCE");
	int m=rs.getInt("MATHEMATICS");
	int h=rs.getInt("HINDI");
	int sc=rs.getInt("SOCIAL_SCIENCE");
	int sum=e+s+m+h+sc;
	totalMarks+=sum;
	out.println("<h2> Total Students Marks Are ="+totalMarks+"/500</h2>");
	count++;
	totalMarks=0;
	
	out.println("<h2>...........................<h2>");
	
	
}
  
out.println("<h2> Total Students Are ="+count+"</h2>");
                out.println("<br>");
                out.println("<html><head>");
                out.println("<title>Click to Go to Home Page</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Click the link below to go to the home page:</h2>");
                out.println("<a href=page.html>Home Page</a>");
                out.println("</body></html>");     
}catch (Exception e2) {System.out.println(e2);}  
          
out.close();  
}  
  
} 