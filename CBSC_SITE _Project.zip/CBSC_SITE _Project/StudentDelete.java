import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class StudentDelete extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String Roll = request.getParameter("StudentRollNumber");
        String Name = request.getParameter("StudentName");

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "SUMIT", "1234");

            Statement stmt = con.createStatement();
            String sq = "DELETE FROM STUDENT WHERE STUDENT_ROLL=" + Roll + "";
            int rowsAffected = stmt.executeUpdate(sq);

            if (rowsAffected > 0) {
                out.print("<h2>Student Deleted Successfully</h2>");
            } else {
                out.print("<h2>Student with Roll Number " + Roll + " not found</h2>");
            }

            out.println("<br>");
            out.println("<html><head>");
            out.println("<title>Click to Go to Home Page</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h2>Click the link below to go to the home page:</h2>");
            out.println("<a href=page.html>Home Page</a>");
            out.println("</body></html>");

        } catch (Exception e2) {
            System.out.println(e2);
        }

        out.close();
    }

}
