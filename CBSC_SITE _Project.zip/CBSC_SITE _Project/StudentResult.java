import java.io.*;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class StudentResult extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String Roll = request.getParameter("StudentRollNumber");
        String Name = request.getParameter("StudentName");
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "SUMIT", "1234");

            Statement stmt = con.createStatement();
            String sq = "select STUDENT_ROLL,STUDENT_NAME,ENGLISH,SCINCE,MATHEMATICS,HINDI,SOCIAL_SCIENCE  FROM STUDENT WHERE STUDENT_ROLL=" + Roll + "";
            ResultSet rs = stmt.executeQuery(sq);
            int totalMarks = 0;
            boolean studentFound = false; // Flag to track if the student was found

            while (rs.next()) {
                studentFound = true; // Student found in the database
                out.println("<h2>" + "Student Roll Number =" + rs.getString(1) + "</h2>");
                out.println("<h2>" + "Student Name        =" + rs.getString(2) + "</h2>");
                out.println("<h2>" + "English Marks       =" + rs.getString(3) + "</h2>");
                out.println("<h2>" + "Science Marks       =" + rs.getString(4) + "</h2>");
                out.println("<h2>" + "Mathematics Marks   =" + rs.getString(5) + "</h2>");
                out.println("<h2>" + "Hindi Marks         =" + rs.getString(6) + "</h2>");
                out.println("<h2>" + "Social Science Marks=" + rs.getString(7) + "</h2>");
                out.println("<br>");

                int e = rs.getInt("ENGLISH");
                int s = rs.getInt("SCINCE");
                int m = rs.getInt("MATHEMATICS");
                int h = rs.getInt("HINDI");
                int sc = rs.getInt("SOCIAL_SCIENCE");
                int sum = e + s + m + h + sc;
                totalMarks += sum;
            }

            if (studentFound) {
                out.println("<h2>Total Number = " + totalMarks + "/500</h2>");

                double percentage = (totalMarks / 500.0) * 100;

                out.println("<h2>Percentage = " + percentage + "% </h2>");
                if (percentage >= 60) {
                    out.println("<h2>You Are Pass And Get 1st Division with = " + percentage + "% Marks</h2>");
                } else if (percentage >= 45) {
                    out.println("<h2>You Are Pass And Get 2nd Division with = " + percentage + "% Marks</h2>");
                } else if (percentage >= 33) {
                    out.println("<h2>You Are Pass And Get 3rd Division with = " + percentage + "% Marks</h2>");
                } else {
                    out.println("<h2>You Fail with = " + percentage + "% Marks</h2>");
                }
			
				out.println("<br>");
                out.println("<html><head>");
                out.println("<title>Click to Go to Home Page</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Click the link below to go to the home page:</h2>");
                out.println("<a href=page.html>Home Page</a>");
                out.println("</body></html>");
            } else {
                // Student not found in the database, print a message
                out.println("<h2>Student with Roll Number " + Roll + " not found</h2>");
				out.println("<br>");
                out.println("<html><head>");
                out.println("<title>Click to Go to Home Page</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h2>Click the link below to go to the home page:</h2>");
                out.println("<a href=page.html>Home Page</a>");
                out.println("</body></html>");
            }

        } catch (Exception e2) {
            System.out.println(e2);
        }

        out.close();
    }
}
